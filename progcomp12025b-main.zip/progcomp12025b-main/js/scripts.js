// função que será chamada no html
function mensagem(){
    alert("Você agora está me seguindo")
}