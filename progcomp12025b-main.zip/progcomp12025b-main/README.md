Disciplina de Programação de Computadores I <br/>
 
// configura o email no git <br/>
1. git config --global user.email "seu@email.com" <br/>
// configura o nome no git <br/>
2. git config --global user.name "Seu nome" <br/>
// cria repositório local <br/>
3. git init <br/>
// adiciona os arquivos para controle de versão <br/>
4. git add . <br/>
// gera uma versão <br/>
5. git commit -m "primeiro site" <br/>
// configura a ramificação do repositório no github <br/>
6. git branch -M main <br/>
// envia o projeto para o github <br/>
7. git push https://github.com/seu_usuario/seu_repositorio.git main <br/>

// quando quiser atualizar o github com as alterações locais:<br/>
repetir os passos 4, 5 e 7
